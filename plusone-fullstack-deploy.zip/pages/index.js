import Head from 'next/head'

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-pink-200 to-blue-200">
      <Head>
        <title>PlusOne</title>
      </Head>
      <h1 className="text-5xl font-bold text-gray-800">Welcome to PlusOne</h1>
      <p className="mt-4 text-xl text-gray-600">Find your companion, anytime, anywhere.</p>
      <button className="mt-6 px-6 py-3 bg-pink-500 text-white rounded-xl shadow-lg hover:bg-pink-600">
        Find a PlusOne Now
      </button>
    </div>
  )
}
