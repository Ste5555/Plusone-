#!/bin/bash
# Supabase + Prisma setup for PlusOne
supabase db push
npx prisma migrate deploy
